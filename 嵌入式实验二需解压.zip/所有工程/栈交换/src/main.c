#include "global.h"
#include "stack.h"
#include "xstack.h"
#include "scheduler.h"
#include "bit_ops.h"
#include "timer0_isr.h"
#include "syscall.h"
#include "semaphore.h"
#include "events.h"
#include "seg_led.h"
#include "button.h"
#include "usbcom.h"
#include "rs485.h"
#include "random.h"

#define TIMESLICE_MS	1
#define T12RL		(65536 - MAIN_Fosc*TIMESLICE_MS/12/1000) 
XDATA u8 character = 0;
XDATA u16 gametime = 0;
XDATA u8 turn = 1;
XDATA u8 allturn = 4;
XDATA float player1 = 0.0;
XDATA float player2 = 0.0;
XDATA u8 poker_point = 0;
XDATA u8 winner = 0;
XDATA unsigned char mypoker[8];


void testproc(u16 param) large reentrant
{
	while(1)
	{
		if((timer0_cnt>>5) & BIT(param))
		{
			SETBIT(led_display_content, param);
		}
		else
		{
			CLEARBIT(led_display_content, param);
		}
	}
}

void testproc2(u16 param) large reentrant
{
	while(1)
	{
		proc_sleep(param);
		led_display_content = ~led_display_content;
	}
}

void testproc3(u16 param) large reentrant
{
	while(1)
	{
		proc_sleep(param);
		led_display_content ^= 0x0f;
	}
}

void testproc4() large reentrant
{
	while(1)
	{
		proc_sleep(500);
		sem_post(0);
		led_display_content |= 0x80;
		sem_wait(0);
		led_display_content &= ~0x80;
	}
}

void testproc5() large reentrant
{
	sem_init(0,0);
	while(1)
	{
		sem_wait(0);
		led_display_content |= 0x40;
		proc_sleep(500);
		sem_post(0);
		led_display_content &= ~0x40;
	}
}

void testproc6(u16 param) large reentrant
{
	while(1)
	{
		proc_wait_evts(EVT_BTN1_DN);
		seg_set_str("HELLO   ");
		usbcom_write("hello \0",0);
		proc_wait_evts(EVT_NAV_R);
		seg_set_str("WORLD   ");
		usbcom_write("world\r\n\0",0);
		proc_wait_evts(EVT_UART1_RECV);
		seg_set_str(usbcom_buf);
	}
}

void testproc7(u16 param) large reentrant
{
	while(1)
	{
		proc_wait_evts(EVT_UART2_RECV | EVT_BTN1_DN);
		if(MY_EVENTS & EVT_BTN1_DN)
		{
			*((u32 *)rs485_buf) = rand32();
			rs485_write(rs485_buf, 4);
			seg_set_number(*((u32 *)rs485_buf));
		}
		else
		{
			seg_set_number(*((u32 *)rs485_buf));
		}
	}
}

// 简单的 CPU-bound 进程用于演示优先级抢占
void cpu_hog(u16 param) large reentrant
{
    while(1) {
			if((timer0_cnt>>5) & BIT(param))
				{
					SETBIT(led_display_content, param);
				}
				else
				{
					CLEARBIT(led_display_content, param);
				}
    }
}

void worker(u16 pid) large reentrant
{
    while(1) {
		if((timer0_cnt>>5) & 8)
		{
			SETBIT(led_display_content, pid);
		}
		else{
			CLEARBIT(led_display_content, pid);
		}
    }
}

void add_of_player(u8 player,u8 poker) large reentrant
{
	XDATA float score = (float)poker;
	// face cards J/Q/K score as 0.5
	if (poker == 11 || poker == 12 || poker == 13) {
		score = 0.5f;
	}
	if(player == 1){
		player1 += score;
		return;
	}
	player2 += score;
}


u8 get_winner() large reentrant
{
	if(player1 > 10.5){
		return 2;
	}
	if(player2 > 10.5){
		return 1;
	}
	if(player1 > player2){
		return 1;
	}
	else if(player1 < player2){
		return 2;
	}
	else{
		return 0;
	}
}
void server()
{
	XDATA u8 usbcom, now_turn, player, poker;
	usbcom = 0x08;
	usbcom_write(&usbcom,1);
	seg_set_n_at_k(4,5);
	seg_set_float_at_three_seg(player1,0);
	seg_set_float_at_three_seg(player2,5);
	now_turn = 2-(turn & 0x01);
	//seg_set_n_at_k(3,now_turn);
	player = rs485_buf[0] & 0x03;
	poker = (rs485_buf[0] & 0x3C)>>2;
	if(now_turn != player){
		SETBIT(led_display_content, 1);
		seg_set_n_at_k(4, 3);
		return;
	}
	add_of_player(player, poker);
	// 标记已处理的 rs485 数据，避免在紧循环中重复处理同一张牌
	rs485_buf[0] = 0;
	rs485_write(&rs485_buf[0],1);
	gametime = ((gametime/10000)+1)*10000;
	seg_set_float_at_three_seg(player1,0);
	seg_set_float_at_three_seg(player2,5);
	//turn++;
	usbcom = 0x0C;
	usbcom_write(&usbcom,1);
	SETBIT(led_display_content, 0);
	if(player1 > 10.5 || player2 > 10.5){
		winner = get_winner();
		seg_set_n_at_k(4,winner);
		usbcom_write(&winner,1);
		return;
	}
}

void client()
{
	XDATA u8 player, poker, usbcom, rs485;
	usbcom = usbcom_buf[0];
	player = usbcom & 0x03;
	poker = (usbcom & 0x3C)>>2;
	seg_set_number_at_a_to_b(poker, 0, 1);
	if (character != player){
		seg_set_n_at_k(4, 3);
		return;
	}
	proc_wait_evts(EVT_BTN1_DN | EVT_BTN2_DN);
	seg_set_n_at_k(4, 5);
	if(MY_EVENTS & EVT_BTN1_DN){
		rs485_write(&usbcom,1);
		seg_set_n_at_k(4, 6);
		return;
	}
	if(MY_EVENTS & EVT_BTN2_DN){
		rs485 = player;
		rs485_write(&rs485,1);
		seg_set_n_at_k(4, 7);
		return;
	}
}

void cs_interrupt()  large reentrant
{
	if (character == 0){
		while(1)
		{
			seg_set_n_at_k(3, turn);
			if(turn == allturn){
				winner = get_winner();
				seg_set_n_at_k(4,winner);
				usbcom_write(&winner,1);
				return;
			}
			gametime++;
			server();
			if(gametime>10000){
				gametime = 0;	
				turn++;
			}
		}
	}
	else {
		while(1)
		{
			proc_wait_evts(EVT_UART1_RECV);
			//proc_wait_evts(EVT_UART2_RECV);
			seg_set_n_at_k(3,5);
			client();
			seg_set_n_at_k(3,6);
		}
	}
}

main()
{
	//initialize kernel stack and xstack pointer
	SP = kernel_stack;
	setxbp(kernel_xstack + KERNEL_XSTACKSIZE);
	
	//set process stacks and swap stacks owner
	process_stack[0][PROCESS_STACKSIZE-1] = 0;
	process_stack[1][PROCESS_STACKSIZE-1] = 1;
	process_stack[2][PROCESS_STACKSIZE-1] = 2;
	process_stack[3][PROCESS_STACKSIZE-1] = 3;
	process_stack[4][PROCESS_STACKSIZE-1] = 4;
	process_stack_swap[0][PROCESS_STACKSIZE-1] = 5;
	process_stack_swap[1][PROCESS_STACKSIZE-1] = 6;
	process_stack_swap[2][PROCESS_STACKSIZE-1] = 7;
	
	//initialize LED pins
	P0M1 &= 0x00;
	P0M0 |= 0xff;
	P2M1 &= 0xf0;
	P2M0 |= 0x0f;
	//select LED, set all off
	P23 = 1;
	P0 = 0;

	//initialize buttons
	buttons_init();
	
	//initialize serial ports
	usbcom_init(115200);
	rs485_init(115200);

	character = 0; // mode

	// 创建 0..4 使用物理栈，5..7 放入 swap（符合项目初始设定）
    start_process_with_prio((u16)worker, 0, 0, 0);
    start_process_with_prio((u16)worker, 1, 1, 1);
    start_process_with_prio((u16)worker, 2, 2, 2);
    start_process_with_prio((u16)worker, 3, 3, 3);
    start_process_with_prio((u16)worker, 4, 4, 4);

    // 增加更多进程以触发 stackswap（它们初始应在 swap 区，根据现有 stack.swap 布局）
    start_process_with_prio((u16)worker, 5, 5, 5);
	start_process_with_prio((u16)worker, 6, 6, 6);
    //start_process_with_prio((u16)worker, 7, 7, 0);

    // 可选：启动一个 cpu_hog 改变 proc_cpu_time/优先级动态行为
    //start_process_with_prio((u16)cpu_hog_test, 2, 2, 7); // 占用并提升优先级影响 victim 选择
    // 然后 self-exit

	/*
	start_process_with_prio((u16)stackswap_stress, 2, 2, 1);
    start_process_with_prio((u16)stackswap_stress, 3, 3, 1);
    start_process_with_prio((u16)stackswap_stress, 4, 4, 1);
    start_process_with_prio((u16)stackswap_stress, 5, 5, 1);
	*/
	
	//start process
	/*
	start_process_with_prio((u16)testproc, 0, 0, 0);   // ??LED?0
	start_process_with_prio((u16)testproc, 1, 1, 1);   // ??LED?0
	start_process_with_prio((u16)testproc, 2, 2, 2);   // ??LED?0
	start_process_with_prio((u16)testproc, 3, 3, 3);   // ??LED?0
	start_process_with_prio((u16)testproc, 4, 4, 4);   // ??LED?0
	start_process_with_prio((u16)testproc, 5, 5, 5);   // ??LED?0
	start_process_with_prio((u16)testproc, 6, 6, 6);   // ??LED?0
	*/
	//start_process((u16)testproc2, 2, 200); // 200ms????
	//start_process((u16)cs_interrupt, 2); // 200ms????
	//start_process_with_prio((u16)cs_interrupt, 2, 2, 7); // 游戏主进程
		
	//initialize PCA2 interrupt (as syscall interrupt)
	//clear CCF2
	CCON &= ~0x04;
	//disable PCA2 module and set ECCF2
	CCAPM2 = 1;
	//low priority interrupt
	PPCA = 0;
	
	//start main timer
	TR0 = 0;														//stop timer
	TMOD &= 0xF0;												//timer mode, 16b autoreload
	AUXR &= 0x7F;												//12T mode
	TL0 = T12RL & 0xff;							//set reload value
	TH0 = (T12RL & 0xff00) >> 8;
	ET0 = EA = 1;												//set interrupt enable
	PT0 = 0;														//set priority to low
	TR0 = 1;														//start timer
	
	//spin
	while(1);
}