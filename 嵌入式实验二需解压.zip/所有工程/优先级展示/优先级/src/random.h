#ifndef _RANDOM_H_
#define _RANDOM_H_

#include "global.h"
#include "ds1302.h"

u32 rand32() large reentrant;
void srand();

#endif