#include "scheduler.h"
#include "seg_led.h"

XDATA u8 process_context[8][18];
XDATA u8 current_process = 8;
DATA u8 flag_nosched = 0;
XDATA u8 process_slot = 0;
XDATA u8 last_process = 8;
XDATA u8 remaining_timeslices = DEFAULT_TIMESLICES;
XDATA u8 proc_time_share[8];
//This determines the number of timeslices assigned when each process is scheduled
//proc_time_share[0] in filled upon initialization. other elements will be filled when
//corresponding process gets started

XDATA u8 proc_priority[8] = {0,0,0,0,0,0,0,0};//���ȼ�
XDATA u32 proc_cpu_time[8] = {0,0,0,0,0,0,0,0};//���ȼ�
XDATA u8 sequence[8] = {0,1,2,3,4,5,6,7};//���ȼ�

//Only processes with 0 sleep countdown can be scheduled
XDATA u16 proc_sleep_countdown[8] ={0, 0, 0, 0, 0, 0, 0, 0};
extern xdata u8 x;
extern xdata u8 y;
void init_random_sequence(int *sequence) {
    XDATA u8 i,j,temp;
    // 先按顺序填充
    for (i = 0; i < 8; i++) {
        sequence[i] = i;
    }
    
    // Fisher-Yates洗牌算法
    for (i = 7; i > 0; i--) {
        j = rand() % (i + 1);
        // 交换
        temp = sequence[i];
        sequence[i] = sequence[j];
        sequence[j] = temp;
    }
}

int next_random(u8 current_index) {
    XDATA u8 i,result;
    init_random_sequence(sequence);
    for (i=0; i<8; i++) {
        if(sequence[i] == current_index) {
            current_index = i;
            break;
        }
    }
    result = sequence[NEXT(current_index)];
    return result;
}
void start_process(u16 entry, u16 pid, u32 param)
{
	//XBPH,L
	process_context[pid][13] = (((u16)process_xstack[pid] + PROCESS_XSTACKSIZE)&0xff00)>>8;
	process_context[pid][14] = ((u16)process_xstack[pid] + PROCESS_XSTACKSIZE)&0x00ff;

	//PCH, PCL
	process_context[pid][15] = (entry&0xff00) >> 8; 
	process_context[pid][16] = (entry&0x00ff);

	
	//SP
	if(get_stack_index(pid)!=-1)
		process_context[pid][17] = process_stack[get_stack_index(pid)]; //stack present in memory, use absolute address
	else
		process_context[pid][17] = 0; //stack in stackswap space, use address relative to stack start
	
	//R4-R7 (param)
	process_context[pid][9] = (param & 0xff000000) >> 24;
	process_context[pid][10] = (param & 0x00ff0000) >> 16;
	process_context[pid][11] = (param & 0x0000ff00) >> 8;
	process_context[pid][12] = (param & 0x000000ff);

	proc_time_share[pid] = DEFAULT_TIMESLICES;
	proc_priority[pid] = DEFAULT_PRIORITY;   // ��ʼ�����ȼ�
    proc_cpu_time[pid] = DEFAULT_CPUTIME;   // ��ʼ�����ȼ�
	process_slot |= BIT(pid);
} 


// u8 select_process()
// {
// 		XDATA u8 tmp_process;
		
// 		//current_process can be 8 (kernel startup) or 9 (idle spin)
// 		//so we have to set current_process to 0 in that situation.
// 		if(current_process >= 8) current_process = 0;
// 		tmp_process = current_process;
    

//     //sequentially check other processes
//     while((tmp_process = NEXT(tmp_process)) != current_process)
//         if(process_ready(tmp_process))
//         	goto SCHEDULER_END;

//     //if no other process can run, check if current process can run again
//     if (process_ready(current_process))
//     {
// 		tmp_process = current_process;
// 		goto SCHEDULER_END;
// 	}
    
//   //Can't find a process to run, reuturn 9(invalid)
// 	//ISR should recognize this and put system to spin until next interrupt
// 	tmp_process = 9;
	
// 	SCHEDULER_END:;
// 	return tmp_process;
// }
u8 select_process()
{
    XDATA u8 i, tmp;
    u8 best_prio = 0xFF;
    u8 found_any = 0;

    if(current_process >= 8) current_process = 0;

    // 找到所有就绪进程中的最高优先级（数值越大优先）
    best_prio = 0;
    for(i = 0; i < 8; i++) {
        if(process_ready(i)) {
            found_any = 1;
            if(proc_priority[i] > best_prio)
                best_prio = proc_priority[i];
        }
    }

    if(!found_any) {
        // 没有可运行的用户进程
        return 9;
    }

    // 在具有最高优先级的进程中做轮转选择（从 current_process 的下一个开始）
    tmp = current_process;
    do {
        tmp = NEXT(tmp);
        if(process_ready(tmp) && proc_priority[tmp] == best_prio)
            return tmp;
    } while(tmp != current_process);

    // 最后检查 current_process 自身（可能在第一次循环里没有匹配到）
    if(process_ready(current_process) && proc_priority[current_process] == best_prio)
        return current_process;

    return 9;
}

void start_process_with_prio(u16 entry, u16 pid, u32 param, u8 priority)
{
    // 调用现有 start_process 保持行为一致
    start_process(entry, pid, param);
    // 再设置优先级（覆盖默认值）
    proc_priority[pid] = priority;
}

u8 preemption_needed()
{
    XDATA u8 i;
    // 如果当前不是用户进程，允许调度
    if(current_process >= 8) return 1;

    for(i = 0; i < 8; i++) {
        if(process_ready(i) && proc_priority[i] > proc_priority[current_process])
            return 1;
    }
    return 0;
}

u8 process_ready(u8 pid)
{
    //Check process exists
    if(!PROC_EXISTS(pid))
        return 0;

    //Check process is not waiting for semaphore
    if(proc_waiting_sem & BIT(pid))
        return 0;

    //Check process is not sleeping or waitiong for events
    if(proc_waiting_evt & BIT(pid))
        return 0;
 
		return 1;
}


//ONLY CALL THIS FUNCTION ATOMICALLY IN ISR!!!
void reschedule()
{
	//kernel or spin context doesn't need to be saved
	if(current_process < 8) 
		save_current_context();

    if(proc_cpu_time[current_process] > (2000 - proc_priority[current_process])){
        if(proc_priority[current_process] > 0){
            proc_priority[current_process] -= 1;
            proc_cpu_time[current_process] = 0;
        }
    }
    
	//select a process to run
	current_process = select_process();
    seg_set_n_at_k(3,x);
		seg_set_n_at_k(7,y);
	if(current_process == 9) goto IDLE_SPIN;
	
	//allocate timeslices and load context
	remaining_timeslices = proc_time_share[current_process];
	if(get_stack_index(current_process) == -1)
		mystackswap(get_stackswap_index(current_process));
		//do stack swap.
	load_current_context();
	return;
	
	IDLE_SPIN:;
	//load address of spin() into interrupt context.
	//allocate 1 timeslice to it.
	interrupt_context[15] = HIGH16((u16)spin);
	interrupt_context[16] = LOW16((u16)spin);
	remaining_timeslices = 1;
	return;
}

void decrement_sleep_counters()
{
    COUNTDOWN(proc_sleep_countdown[0], interrupt_counter);
    COUNTDOWN(proc_sleep_countdown[1], interrupt_counter);
    COUNTDOWN(proc_sleep_countdown[2], interrupt_counter);
    COUNTDOWN(proc_sleep_countdown[3], interrupt_counter);
    COUNTDOWN(proc_sleep_countdown[4], interrupt_counter);
    COUNTDOWN(proc_sleep_countdown[5], interrupt_counter);
    COUNTDOWN(proc_sleep_countdown[6], interrupt_counter);
    COUNTDOWN(proc_sleep_countdown[7], interrupt_counter);
}



