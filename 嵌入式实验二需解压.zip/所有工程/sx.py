import serial
import time
import tkinter as tk
import threading
from tkinter import messagebox
import queue
import logging
import random

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')

# ------- 配置 -------
SERIAL_PORT = 'COM4'      # 根据需要修改
BAUDRATE = 115200
TIMEOUT = 0.5

BOARD_SIZE = 10           # 10x10 棋盘
CELL_SIZE = 60            # 每格像素大小（可以调）
MARGIN = 30               # 棋盘外边距
STONE_RADIUS = CELL_SIZE // 2 - 6

# player id 约定：发送端第一个字节为 10 或 11
PLAYER_ID_MAP = {10: 0, 11: 1}  # map to 0 (黑=A) / 1 (白=B)
REVERSE_PLAYER_ID = {0: 10, 1: 11}

# AI 执行延时（毫秒）
AI_DELAY_MS = 600

# ------- 全局状态 -------
lst = [0, 0, 0]
serial_thread = None
stop_thread = False

move_queue = queue.Queue()  # 串口线程放入三元组 (raw_p, x, y)

# 棋盘表示：-1 空格，0 黑，1 白
board = [[-1] * BOARD_SIZE for _ in range(BOARD_SIZE)]

# GUI refs
windows = None
canvas = None
status_label = None
last_move_label = None

# 串口缓冲及锁（复用单一 Serial 对象）
recv_buffer = bytearray()
buffer_lock = threading.Lock()
serial_conn = None
serial_lock = threading.Lock()

# game flags
game_over = False
pending_serial_move = None  # (player, x, y)

# UI vars (will be created in build_ui)
game_mode_var = None          # "A_vs_B", "Human_vs_AI", "AI_vs_AI"
human_side_var = None         # "Black" or "White" (used in Human_vs_AI)
ai_black_var = None           # bool - whether AI controls black (for A_vs_B mode)
ai_white_var = None           # bool - whether AI controls white
auto_reset_var = None         # auto reset on win

# ----------------- helper / mapping -----------------
def is_ai_player(player):
    # 判断给定玩家是否由 AI 控制
    # 输入: player (0 表示 A/黑, 1 表示 B/白)
    # 输出: bool - True 表示该玩家由 AI 控制
    # 逻辑基于当前界面上的模式设置：AI_vs_AI、Human_vs_AI、A_vs_B
    mode = game_mode_var.get()
    if mode == "AI_vs_AI":
        return True
    if mode == "Human_vs_AI":
        # Human_vs_AI 模式下，human_side_var 指定了人的一方，另一方为 AI
        human_side = 0 if human_side_var.get() == "Black" else 1
        return player != human_side
    if mode == "A_vs_B":
        # A_vs_B 模式下使用复选框分别指定哪一方由 AI 控制
        if player == 0:
            return ai_black_var.get()
        else:
            return ai_white_var.get()
    return False

def get_next_player():
    # 计算当前应该下子的玩家（0 或 1）。根据已落子数量奇偶性决定。
    total = sum(1 for row in board for v in row if v != -1)
    return 0 if total % 2 == 0 else 1

def next_player_is_ai():
    # 返回值表示当前轮到下子的玩家是否是 AI
    return is_ai_player(get_next_player())

def serial_map_to_player(raw_p):
    # 将串口发送的 raw_p（例如 10/11）映射到程序内的 player id (0/1)
    # 在不同模式下处理方式不同：
    # - AI_vs_AI: 忽略外部串口输入，返回 None
    # - Human_vs_AI: 串口视为人的操作，返回 human_side（0 或 1）
    # - A_vs_B: 使用 PLAYER_ID_MAP 映射
    mode = game_mode_var.get()
    if mode == "AI_vs_AI":
        return None
    if mode == "Human_vs_AI":
        human_side = 0 if human_side_var.get() == "Black" else 1
        return human_side
    return PLAYER_ID_MAP.get(raw_p, None)

# ----------------- core logic -----------------
def reset_board():
    # 重置棋盘和状态：清空 board，清除 pending 串口落子，重绘并触发 AI（如需要）
    global board, game_over, pending_serial_move
    board = [[-1] * BOARD_SIZE for _ in range(BOARD_SIZE)]
    game_over = False
    pending_serial_move = None
    draw_board()
    set_status("棋盘已重置")
    schedule_ai_for_next()

def draw_board():
    # 在画布上绘制棋盘格和当前棋子状态
    canvas.delete("all")
    width = MARGIN * 2 + CELL_SIZE * (BOARD_SIZE - 1)
    canvas.create_rectangle(0, 0, width, width, fill="#F0D9B5", outline="#F0D9B5")
    for i in range(BOARD_SIZE):
        pos = MARGIN + i * CELL_SIZE
        canvas.create_line(MARGIN, pos, width - MARGIN, pos, fill="black")
        canvas.create_line(pos, MARGIN, pos, width - MARGIN, fill="black")
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            v = board[y][x]
            if v != -1:
                draw_stone(x, y, v)

def draw_stone(x, y, player):
    # 在画布上绘制单个棋子
    # x,y: 棋盘坐标 (0..BOARD_SIZE-1)，player: 0=黑(A),1=白(B)
    cx = MARGIN + x * CELL_SIZE
    cy = MARGIN + (BOARD_SIZE - 1 - y) * CELL_SIZE
    r = STONE_RADIUS
    color = "black" if player == 0 else "white"
    canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill=color, outline="black")

def set_status(txt):
    # 更新底部状态栏文字（容错）
    try:
        status_label.config(text=txt)
    except Exception:
        pass

def board_coord_from_pixel(px, py):
    # 将画布像素坐标转换为棋盘坐标 (x,y)
    rx = (px - MARGIN) / CELL_SIZE
    ry = (py - MARGIN) / CELL_SIZE
    x = int(round(rx))
    y_from_top = int(round(ry))
    y = (BOARD_SIZE - 1) - y_from_top
    return x, y

def is_valid_pos(x, y):
    # 检查坐标是否在棋盘范围内
    return 0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE

def place_move(player, x, y, from_serial=False):
    # 尝试在 (x,y) 为 player 下子，包含校验、胜负判断与 UI 更新
    # 参数: player (0/1), x,y: 棋盘坐标, from_serial: 是否来源于串口（额外记录）
    global game_over
    if game_over:
        logging.info("游戏已结束，忽略下子")
        return False
    if not is_valid_pos(x, y):
        if from_serial:
            logging.info("收到非法坐标：%s,%s", x, y)
        return False
    if board[y][x] != -1:
        if from_serial:
            logging.info("格子已被占用：%s,%s", x, y)
        return False
    # 落子并刷新显示
    board[y][x] = player
    draw_board()
    try:
        last_move_label.config(text=f"上一步: 玩家 {'A' if player==0 else 'B'} -> ({x},{y})")
    except Exception:
        pass
    # 胜利检测
    if check_win(player, x, y):
        winner = 'A(黑)' if player == 0 else 'B(白)'
        messagebox.showinfo("游戏结束", f"{winner} 胜利！")
        set_status(f"{winner} 胜利！按重置开始新局。")
        game_over = True
        if auto_reset_var.get():
            windows.after(1500, reset_board)
    # 检查是否平局（棋盘已满）
    full = all(v != -1 for row in board for v in row)
    if full:
        messagebox.showinfo("平局", "棋盘已满，结果为平局。")
        set_status("平局：棋盘已满")
        game_over = True
        if auto_reset_var.get():
            windows.after(1500, reset_board)
        return True

    set_status(f"玩家 {'A' if player==0 else 'B'} 下子：({x},{y})")
    if not game_over:
        schedule_ai_for_next()
    return True

def check_win(player, x, y):
    # 检查玩家 player 在 (x,y) 落子后是否形成 5 连（任意方向）
    directions = [(1,0),(0,1),(1,1),(1,-1)]
    for dx,dy in directions:
        count = 1
        nx,ny = x+dx,y+dy
        while 0<=nx<BOARD_SIZE and 0<=ny<BOARD_SIZE and board[ny][nx]==player:
            count +=1
            nx += dx; ny += dy
        nx,ny = x-dx, y-dy
        while 0<=nx<BOARD_SIZE and 0<=ny<BOARD_SIZE and board[ny][nx]==player:
            count +=1
            nx -= dx; ny -= dy
        if count>=5:
            return True
    return False

# ----------------- AI -----------------
def find_immediate_win(player):
    # 遍历所有空位，查找能立刻获胜的落子，找到即返回 (x,y)
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            if board[y][x]==-1:
                board[y][x]=player
                win = check_win(player,x,y)
                board[y][x]=-1
                if win:
                    return x,y
    return None

def find_block_move(player):
    # 查找阻止对方立即获胜的防守落子：模拟对手在每个空位落子，若对手会获胜则返回该位置
    opponent = 1-player
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            if board[y][x]==-1:
                board[y][x]=opponent
                opp_win = check_win(opponent,x,y)
                board[y][x]=-1
                if opp_win:
                    return x,y
    return None

def find_random_nearby():
    # New heuristic: generate candidate moves near existing stones and score them
    occupied = [(x,y) for y in range(BOARD_SIZE) for x in range(BOARD_SIZE) if board[y][x]!=-1]
    empties = [(x,y) for y in range(BOARD_SIZE) for x in range(BOARD_SIZE) if board[y][x]==-1]
    if not empties:
        return None
    if not occupied:
        # prefer center if board empty
        center = BOARD_SIZE // 2
        if board[center][center] == -1:
            return (center, center)
        return random.choice(empties)

    # collect candidates within radius 3 of any occupied cell
    R = 3
    candidates = set()
    for ox,oy in occupied:
        for dx in range(-R, R+1):
            for dy in range(-R, R+1):
                nx,ny = ox+dx, oy+dy
                if 0<=nx<BOARD_SIZE and 0<=ny<BOARD_SIZE and board[ny][nx]==-1:
                    candidates.add((nx,ny))

    if not candidates:
        candidates = set(empties)

    # 评估候选点并选择评分最高的
    best = None
    best_score = None
    for (cx,cy) in candidates:
        s = evaluate_move_score(None, cx, cy)
        if best is None or s > best_score:
            best = (cx,cy)
            best_score = s
        elif s == best_score and random.random() < 0.5:
            best = (cx,cy)

    return best


def evaluate_move_score(player_hint, x, y):
    """
    给定落子位置 (x,y)，对该点进行启发式评分。
    如果 player_hint 为 None，则评价为当前轮到玩家（get_next_player）的视角。
    返回数值，值越大表示越好。
    """
    # choose perspective: evaluate for current side and opponent
    me = get_next_player() if player_hint is None else player_hint
    opp = 1 - me

    # helper to count contiguous stones in one direction
    def count_dir(px, py, dx, dy, player):
        cnt = 0
        nx, ny = px+dx, py+dy
        while 0<=nx<BOARD_SIZE and 0<=ny<BOARD_SIZE and board[ny][nx]==player:
            cnt += 1
            nx += dx; ny += dy
        return cnt

    def line_score(px, py, player):
        # directions: (1,0),(0,1),(1,1),(1,-1)
        dirs = [(1,0),(0,1),(1,1),(1,-1)]
        score = 0
        for dx,dy in dirs:
            left = count_dir(px, py, -dx, -dy, player)
            right = count_dir(px, py, dx, dy, player)
            total = left + 1 + right
            # open ends check
            open_ends = 0
            lx, ly = px - dx*(left+1), py - dy*(left+1)
            rx, ry = px + dx*(right+1), py + dy*(right+1)
            if 0<=lx<BOARD_SIZE and 0<=ly<BOARD_SIZE and board[ly][lx]==-1:
                open_ends += 1
            if 0<=rx<BOARD_SIZE and 0<=ry<BOARD_SIZE and board[ry][rx]==-1:
                open_ends += 1

            # scoring: prioritize longer lines and open ends
            if total >= 5:
                return 1000000  # immediate win
            # base weight: exponential on length
            base = 10 ** total
            if open_ends == 2:
                base *= 2
            score += base
        return score

    # simulate placing for me and opp
    # Temporarily set board[y][x] to me for scoring, but restore after
    orig = board[y][x]
    board[y][x] = me
    my_score = line_score(x, y, me)
    board[y][x] = opp
    opp_score = line_score(x, y, opp)
    board[y][x] = orig

    # final score favours my making long lines but heavily penalizes allowing opponent
    # If my move makes immediate win, pick it
    if my_score >= 1000000:
        return 10000000
    # If opponent would have immediate win by placing here (rare), give high defensive weight
    if opp_score >= 1000000:
        return 9000000

    score = my_score * 1.0
    # block opponent threats more strongly
    score += opp_score * 1.2

    # small center bias
    cx = (BOARD_SIZE - 1) / 2.0
    center_dist = abs(x - cx) + abs(y - cx)
    score -= center_dist * 2
    return score

def make_ai_move(player):
    # AI 根据启发式策略决定并下子：先找必胜，再找阻挡，否则选择附近最佳点
    if game_over:
        return
    pos = find_immediate_win(player)
    if pos is None:
        pos = find_block_move(player)
    if pos is None:
        pos = find_random_nearby()
    if pos:
        x,y = pos
        place_move(player,x,y,from_serial=False)

def schedule_ai_for_next():
    # 如果下一个玩家是 AI，则在延时后调用 make_ai_move
    if game_over:
        return
    if next_player_is_ai():
        next_p = get_next_player()
        windows.after(AI_DELAY_MS, lambda p=next_p: make_ai_move(p))

# ----------------- serial io (复用 serial_conn) -----------------
def serial_reader_thread(port=SERIAL_PORT, baud=BAUDRATE):
    # 后台线程：从串口读取原始字节流，按三字节一组解析为 (raw_p,x,y) 并放入 move_queue
    global stop_thread, recv_buffer, serial_conn
    try:
        logging.info("串口读线程开始")
        while not stop_thread:
            try:
                with serial_lock:
                    conn = serial_conn
                    n = conn.in_waiting if conn and conn.is_open else 0
            except Exception:
                n = 0
            if n > 0:
                try:
                    with serial_lock:
                        data = serial_conn.read(n)
                except Exception:
                    logging.exception("读串口失败")
                    data = b''
                if data:
                    logging.info("接收原始: %r", data)
                    with buffer_lock:
                        recv_buffer.extend(data)
                        while len(recv_buffer) >= 3:
                            raw_p = recv_buffer[0]
                            x = recv_buffer[1]
                            y = recv_buffer[2]
                            del recv_buffer[:3]
                            logging.info("收到串口三元组: %s,%s,%s", hex(raw_p), x, y)
                            move_queue.put((raw_p, x, y))
            time.sleep(0.01)
    except Exception:
        logging.exception("串口读线程异常")
    finally:
        logging.info("串口读线程退出")

def start_serial_thread():
    # 尝试打开主串口连接并启动串口读取线程（守护线程）
    global serial_thread, stop_thread, serial_conn
    stop_thread = False
    try:
        serial_conn = serial.Serial(port=SERIAL_PORT, baudrate=BAUDRATE, timeout=TIMEOUT)
        try:
            serial_conn.reset_input_buffer()
        except Exception:
            pass
        logging.info("串口已打开（主连接）：%s %dbps", SERIAL_PORT, BAUDRATE)
    except Exception:
        logging.exception("打开串口失败，后续读写会尝试回退方式")
        serial_conn = None
    serial_thread = threading.Thread(target=serial_reader_thread, daemon=True, name="SerialReader")
    serial_thread.start()
    logging.info("串口读线程已启动")

def stop_serial_thread():
    # 请求并等待串口线程停止，同时关闭主串口连接（如果存在）
    global stop_thread, serial_conn, serial_thread
    stop_thread = True
    logging.info("请求停止串口线程")
    try:
        if serial_thread is not None:
            serial_thread.join(timeout=1.0)
    except Exception:
        pass
    try:
        if serial_conn is not None:
            with serial_lock:
                if serial_conn.is_open:
                    serial_conn.close()
            serial_conn = None
            logging.info("主串口连接已关闭")
    except Exception:
        logging.exception("关闭串口失败")

def send_serial_click_byte(value=1):
    """向物理串口发送单字节点击标志。

    优先使用共享的 serial_conn；若其不可用则临时打开串口发送一次。
    参数 value: 要发送的整数（只取低 8 位）。
    """
    global serial_conn
    try:
        if serial_conn is None or not getattr(serial_conn, "is_open", False):
            logging.warning("serial_conn 未打开，尝试临时打开发送")
            # 回退：临时打开端口发送（如果被占用会抛异常）
            s = serial.Serial(port=SERIAL_PORT, baudrate=BAUDRATE, timeout=0.5)
            s.write(bytes([value & 0xFF]))
            s.flush()
            s.close()
            logging.info("临时打开串口并发送点击字节: %s", hex(value & 0xFF))
            return
        with serial_lock:
            serial_conn.write(bytes([value & 0xFF]))
            serial_conn.flush()
        logging.info("通过共享串口发送点击字节: %s", hex(value & 0xFF))
    except Exception:
        logging.exception("发送点击标志失败")

def send_serial_click_async(value=1):
    # 异步发送串口点击字节，防止阻塞 UI
    threading.Thread(target=send_serial_click_byte, args=(value,), daemon=True).start()


def on_canvas_click(event):
    # 画布点击回调：将像素坐标转换为棋盘坐标并尝试落子（仅限人类回合）
    global game_over
    if game_over:
        return
    next_p = get_next_player()
    if is_ai_player(next_p):
        set_status("当前为 AI 回合，等待 AI 下子...")
        return
    x,y = board_coord_from_pixel(event.x, event.y)
    if is_valid_pos(x,y) and board[y][x]==-1:
        ok = place_move(next_p, x, y, from_serial=False)
        if ok:
            # 发送单字节 0x01 表示点击发生（异步）
            send_serial_click_async(1)

def process_move_queue():
    # 主线程定期检查 move_queue 中来自串口的落子请求并处理。
    # 若当前不该该串口玩家下子，则将其暂存至 pending_serial_move，稍后再尝试。
    global pending_serial_move
    if pending_serial_move and not game_over:
        p,x,y = pending_serial_move
        if get_next_player() == p:
            logging.info("处理 pending 串口落子: %s,%s,%s", p, x, y)
            place_move(p,x,y,from_serial=True)
            pending_serial_move = None
        else:
            windows.after(50, process_move_queue)
            return

    while not move_queue.empty() and not game_over:
        try:
            raw_p, x, y = move_queue.get_nowait()
        except queue.Empty:
            break
        mapped = serial_map_to_player(raw_p)
        if mapped is None:
            logging.info("当前模式下忽略串口输入: raw %s", raw_p)
            continue
        # 默认行为：只有当轮到该玩家时才处理，否则暂存
        if get_next_player() == mapped:
            logging.info("处理串口落子: mapped %s -> (%s,%s)", mapped, x, y)
            place_move(mapped, x, y, from_serial=True)
        else:
            logging.info("暂存串口落子: mapped %s -> (%s,%s)", mapped, x, y)
            pending_serial_move = (mapped, x, y)
            break

    windows.after(50, process_move_queue)

def build_ui():
    # 创建并返回主窗口，构建画布、控制按钮和变量绑定
    global windows, canvas, status_label, last_move_label
    global game_mode_var, human_side_var, ai_black_var, ai_white_var
    global auto_reset_var

    windows = tk.Tk()
    windows.title("五子棋 - 多模式（A/B/AI/串口） (10x10, 左下为(0,0))")
    width = MARGIN * 2 + CELL_SIZE * (BOARD_SIZE - 1)
    windows.geometry(f"{width}x{width+220}")

    canvas_frame = tk.Frame(windows)
    canvas_frame.pack()
    canvas_widget = tk.Canvas(canvas_frame, width=width, height=width, bg="#F0D9B5")
    canvas_widget.pack()
    canvas_widget.bind("<Button-1>", on_canvas_click)

    ctrl = tk.Frame(windows)
    ctrl.pack(fill="x", pady=6)

    tk.Label(ctrl, text="模式:").pack(side="left")
    game_mode_var = tk.StringVar(value="A_vs_B")
    tk.OptionMenu(ctrl, game_mode_var, "A_vs_B", "Human_vs_AI", "AI_vs_AI").pack(side="left", padx=4)

    tk.Label(ctrl, text=" 人类方:").pack(side="left")
    human_side_var = tk.StringVar(value="Black")
    tk.OptionMenu(ctrl, human_side_var, "Black", "White").pack(side="left", padx=4)

    ai_black_var = tk.BooleanVar(value=False)
    ai_white_var = tk.BooleanVar(value=False)
    tk.Checkbutton(ctrl, text="Black AI", variable=ai_black_var).pack(side="left", padx=4)
    tk.Checkbutton(ctrl, text="White AI", variable=ai_white_var).pack(side="left", padx=4)

    # （已移除）串口合并 A/B 功能

    auto_reset_var = tk.BooleanVar(value=False)
    tk.Checkbutton(ctrl, text="胜利后自动重置", variable=auto_reset_var).pack(side="left", padx=6)

    tk.Button(windows, text="立即 AI 下一步", command=lambda: make_ai_move(get_next_player())).pack(pady=4)

    status_label_local = tk.Label(windows, text="坐标系：左下为 (0,0)。等待串口输入或点击下子", anchor="w")
    status_label_local.pack(fill="x", padx=6)
    tk.Button(windows, text="重置棋盘", command=reset_board).pack(pady=2)
    last_move = tk.Label(windows, text="上一步: 无")
    last_move.pack()

    # bind refs
    canvas = canvas_widget
    status_label = status_label_local
    last_move_label = last_move

    return windows

def on_closing():
    # 退出回调：询问确认后停止串口线程并销毁窗口
    if messagebox.askokcancel("退出", "确定要退出吗？"):
        stop_serial_thread()
        time.sleep(0.2)
        try:
            windows.destroy()
        except Exception:
            pass

def main():
    global windows, canvas, status_label, last_move_label
    windows = build_ui()
    draw_board()
    start_serial_thread()
    windows.after(50, process_move_queue)
    windows.after(200, schedule_ai_for_next)
    windows.protocol("WM_DELETE_WINDOW", on_closing)
    windows.mainloop()

if __name__ == "__main__":
    main()
import serial
import time
import tkinter as tk
import threading
from tkinter import messagebox
import queue
import logging
import random

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')

# ------- 配置 -------
SERIAL_PORT = 'COM4'      # 根据需要修改
BAUDRATE = 115200
TIMEOUT = 0.5

BOARD_SIZE = 10           # 10x10 棋盘
CELL_SIZE = 60            # 每格像素大小（可以调）
MARGIN = 30               # 棋盘外边距
STONE_RADIUS = CELL_SIZE // 2 - 6

# player id 约定：发送端第一个字节为 10 或 11
PLAYER_ID_MAP = {10: 0, 11: 1}  # map to 0 (黑=A) / 1 (白=B)
REVERSE_PLAYER_ID = {0: 10, 1: 11}

# AI 执行延时（毫秒）
AI_DELAY_MS = 600

# ------- 全局状态 -------
lst = [0, 0, 0]
serial_thread = None
stop_thread = False

move_queue = queue.Queue()  # 串口线程放入三元组 (raw_p, x, y)

# 棋盘表示：-1 空格，0 黑，1 白
board = [[-1] * BOARD_SIZE for _ in range(BOARD_SIZE)]

# GUI refs
windows = None
canvas = None
status_label = None
last_move_label = None

# 串口缓冲及锁（复用单一 Serial 对象）
recv_buffer = bytearray()
buffer_lock = threading.Lock()
serial_conn = None
serial_lock = threading.Lock()

# game flags
game_over = False
pending_serial_move = None  # (player, x, y)

# UI vars (will be created in build_ui)
game_mode_var = None          # "A_vs_B", "Human_vs_AI", "AI_vs_AI"
human_side_var = None         # "Black" or "White" (used in Human_vs_AI)
ai_black_var = None           # bool - whether AI controls black (for A_vs_B mode)
ai_white_var = None           # bool - whether AI controls white
auto_reset_var = None         # auto reset on win

# ----------------- helper / mapping -----------------
def is_ai_player(player):
    mode = game_mode_var.get()
    if mode == "AI_vs_AI":
        return True
    if mode == "Human_vs_AI":
        human_side = 0 if human_side_var.get() == "Black" else 1
        return player != human_side
    if mode == "A_vs_B":
        if player == 0:
            return ai_black_var.get()
        else:
            return ai_white_var.get()
    return False

def get_next_player():
    total = sum(1 for row in board for v in row if v != -1)
    return 0 if total % 2 == 0 else 1

def next_player_is_ai():
    return is_ai_player(get_next_player())

def serial_map_to_player(raw_p):
    mode = game_mode_var.get()
    if mode == "AI_vs_AI":
        return None
    if mode == "Human_vs_AI":
        human_side = 0 if human_side_var.get() == "Black" else 1
        return human_side
    return PLAYER_ID_MAP.get(raw_p, None)

# ----------------- core logic -----------------
def reset_board():
    global board, game_over, pending_serial_move
    board = [[-1] * BOARD_SIZE for _ in range(BOARD_SIZE)]
    game_over = False
    pending_serial_move = None
    draw_board()
    set_status("棋盘已重置")
    schedule_ai_for_next()

def draw_board():
    canvas.delete("all")
    width = MARGIN * 2 + CELL_SIZE * (BOARD_SIZE - 1)
    canvas.create_rectangle(0, 0, width, width, fill="#F0D9B5", outline="#F0D9B5")
    for i in range(BOARD_SIZE):
        pos = MARGIN + i * CELL_SIZE
        canvas.create_line(MARGIN, pos, width - MARGIN, pos, fill="black")
        canvas.create_line(pos, MARGIN, pos, width - MARGIN, fill="black")
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            v = board[y][x]
            if v != -1:
                draw_stone(x, y, v)

def draw_stone(x, y, player):
    cx = MARGIN + x * CELL_SIZE
    cy = MARGIN + (BOARD_SIZE - 1 - y) * CELL_SIZE
    r = STONE_RADIUS
    color = "black" if player == 0 else "white"
    canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill=color, outline="black")

def set_status(txt):
    try:
        status_label.config(text=txt)
    except Exception:
        pass

def board_coord_from_pixel(px, py):
    rx = (px - MARGIN) / CELL_SIZE
    ry = (py - MARGIN) / CELL_SIZE
    x = int(round(rx))
    y_from_top = int(round(ry))
    y = (BOARD_SIZE - 1) - y_from_top
    return x, y

def is_valid_pos(x, y):
    return 0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE

def place_move(player, x, y, from_serial=False):
    global game_over
    if game_over:
        logging.info("游戏已结束，忽略下子")
        return False
    if not is_valid_pos(x, y):
        if from_serial:
            logging.info("收到非法坐标：%s,%s", x, y)
        return False
    if board[y][x] != -1:
        if from_serial:
            logging.info("格子已被占用：%s,%s", x, y)
        return False
    board[y][x] = player
    draw_board()
    try:
        last_move_label.config(text=f"上一步: 玩家 {'A' if player==0 else 'B'} -> ({x},{y})")
    except Exception:
        pass
    if check_win(player, x, y):
        winner = 'A(黑)' if player == 0 else 'B(白)'
        messagebox.showinfo("游戏结束", f"{winner} 胜利！")
        set_status(f"{winner} 胜利！按重置开始新局。")
        game_over = True
        if auto_reset_var.get():
            windows.after(1500, reset_board)
    # 如果没有胜利，检查棋盘是否已满
    full = all(v != -1 for row in board for v in row)
    if full:
        messagebox.showinfo("平局", "棋盘已满，结果为平局。")
        set_status("平局：棋盘已满")
        game_over = True
        if auto_reset_var.get():
            windows.after(1500, reset_board)
        return True

    set_status(f"玩家 {'A' if player==0 else 'B'} 下子：({x},{y})")
    if not game_over:
        schedule_ai_for_next()
    return True

def check_win(player, x, y):
    directions = [(1,0),(0,1),(1,1),(1,-1)]
    for dx,dy in directions:
        count = 1
        nx,ny = x+dx,y+dy
        while 0<=nx<BOARD_SIZE and 0<=ny<BOARD_SIZE and board[ny][nx]==player:
            count +=1
            nx += dx; ny += dy
        nx,ny = x-dx, y-dy
        while 0<=nx<BOARD_SIZE and 0<=ny<BOARD_SIZE and board[ny][nx]==player:
            count +=1
            nx -= dx; ny -= dy
        if count>=5:
            return True
    return False

# ----------------- AI -----------------
def find_immediate_win(player):
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            if board[y][x]==-1:
                board[y][x]=player
                win = check_win(player,x,y)
                board[y][x]=-1
                if win:
                    return x,y
    return None

def find_block_move(player):
    opponent = 1-player
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            if board[y][x]==-1:
                board[y][x]=opponent
                opp_win = check_win(opponent,x,y)
                board[y][x]=-1
                if opp_win:
                    return x,y
    return None

def find_random_nearby():
    # New heuristic: generate candidate moves near existing stones and score them
    occupied = [(x,y) for y in range(BOARD_SIZE) for x in range(BOARD_SIZE) if board[y][x]!=-1]
    empties = [(x,y) for y in range(BOARD_SIZE) for x in range(BOARD_SIZE) if board[y][x]==-1]
    if not empties:
        return None
    if not occupied:
        # prefer center if board empty
        center = BOARD_SIZE // 2
        if board[center][center] == -1:
            return (center, center)
        return random.choice(empties)

    # collect candidates within radius 3 of any occupied cell
    R = 3
    candidates = set()
    for ox,oy in occupied:
        for dx in range(-R, R+1):
            for dy in range(-R, R+1):
                nx,ny = ox+dx, oy+dy
                if 0<=nx<BOARD_SIZE and 0<=ny<BOARD_SIZE and board[ny][nx]==-1:
                    candidates.add((nx,ny))

    if not candidates:
        candidates = set(empties)

    # evaluate candidates and pick best scored move
    best = None
    best_score = None
    for (cx,cy) in candidates:
        s = evaluate_move_score(None, cx, cy)
        if best is None or s > best_score:
            best = (cx,cy)
            best_score = s
        elif s == best_score and random.random() < 0.5:
            best = (cx,cy)

    return best


def evaluate_move_score(player_hint, x, y):
    """
    给定落子位置 (x,y)，对该点进行启发式评分。
    如果 player_hint 为 None，则评价为当前轮到玩家（get_next_player）的视角。
    返回数值，值越大表示越好。
    """
    # choose perspective: evaluate for current side and opponent
    me = get_next_player() if player_hint is None else player_hint
    opp = 1 - me

    # helper to count contiguous stones in one direction
    def count_dir(px, py, dx, dy, player):
        cnt = 0
        nx, ny = px+dx, py+dy
        while 0<=nx<BOARD_SIZE and 0<=ny<BOARD_SIZE and board[ny][nx]==player:
            cnt += 1
            nx += dx; ny += dy
        return cnt

    def line_score(px, py, player):
        # directions: (1,0),(0,1),(1,1),(1,-1)
        dirs = [(1,0),(0,1),(1,1),(1,-1)]
        score = 0
        for dx,dy in dirs:
            left = count_dir(px, py, -dx, -dy, player)
            right = count_dir(px, py, dx, dy, player)
            total = left + 1 + right
            # open ends check
            open_ends = 0
            lx, ly = px - dx*(left+1), py - dy*(left+1)
            rx, ry = px + dx*(right+1), py + dy*(right+1)
            if 0<=lx<BOARD_SIZE and 0<=ly<BOARD_SIZE and board[ly][lx]==-1:
                open_ends += 1
            if 0<=rx<BOARD_SIZE and 0<=ry<BOARD_SIZE and board[ry][rx]==-1:
                open_ends += 1

            # scoring: prioritize longer lines and open ends
            if total >= 5:
                return 1000000  # immediate win
            # base weight: exponential on length
            base = 10 ** total
            if open_ends == 2:
                base *= 2
            score += base
        return score

    # simulate placing for me and opp
    # Temporarily set board[y][x] to me for scoring, but restore after
    orig = board[y][x]
    board[y][x] = me
    my_score = line_score(x, y, me)
    board[y][x] = opp
    opp_score = line_score(x, y, opp)
    board[y][x] = orig

    # final score favours my making long lines but heavily penalizes allowing opponent
    # If my move makes immediate win, pick it
    if my_score >= 1000000:
        return 10000000
    # If opponent would have immediate win by placing here (rare), give high defensive weight
    if opp_score >= 1000000:
        return 9000000

    score = my_score * 1.0
    # block opponent threats more strongly
    score += opp_score * 1.2

    # small center bias
    cx = (BOARD_SIZE - 1) / 2.0
    center_dist = abs(x - cx) + abs(y - cx)
    score -= center_dist * 2
    return score

def make_ai_move(player):
    if game_over:
        return
    pos = find_immediate_win(player)
    if pos is None:
        pos = find_block_move(player)
    if pos is None:
        pos = find_random_nearby()
    if pos:
        x,y = pos
        place_move(player,x,y,from_serial=False)

def schedule_ai_for_next():
    if game_over:
        return
    if next_player_is_ai():
        next_p = get_next_player()
        windows.after(AI_DELAY_MS, lambda p=next_p: make_ai_move(p))

# ----------------- serial io (复用 serial_conn) -----------------
def serial_reader_thread(port=SERIAL_PORT, baud=BAUDRATE):
    global stop_thread, recv_buffer, serial_conn
    try:
        logging.info("串口读线程开始")
        while not stop_thread:
            try:
                with serial_lock:
                    conn = serial_conn
                    n = conn.in_waiting if conn and conn.is_open else 0
            except Exception:
                n = 0
            if n > 0:
                try:
                    with serial_lock:
                        data = serial_conn.read(n)
                except Exception:
                    logging.exception("读串口失败")
                    data = b''
                if data:
                    logging.info("接收原始: %r", data)
                    with buffer_lock:
                        recv_buffer.extend(data)
                        while len(recv_buffer) >= 3:
                            raw_p = recv_buffer[0]
                            x = recv_buffer[1]
                            y = recv_buffer[2]
                            del recv_buffer[:3]
                            logging.info("收到串口三元组: %s,%s,%s", hex(raw_p), x, y)
                            move_queue.put((raw_p, x, y))
            time.sleep(0.01)
    except Exception:
        logging.exception("串口读线程异常")
    finally:
        logging.info("串口读线程退出")

def start_serial_thread():
    global serial_thread, stop_thread, serial_conn
    stop_thread = False
    try:
        serial_conn = serial.Serial(port=SERIAL_PORT, baudrate=BAUDRATE, timeout=TIMEOUT)
        try:
            serial_conn.reset_input_buffer()
        except Exception:
            pass
        logging.info("串口已打开（主连接）：%s %dbps", SERIAL_PORT, BAUDRATE)
    except Exception:
        logging.exception("打开串口失败，后续读写会尝试回退方式")
        serial_conn = None
    serial_thread = threading.Thread(target=serial_reader_thread, daemon=True, name="SerialReader")
    serial_thread.start()
    logging.info("串口读线程已启动")

def stop_serial_thread():
    global stop_thread, serial_conn, serial_thread
    stop_thread = True
    logging.info("请求停止串口线程")
    try:
        if serial_thread is not None:
            serial_thread.join(timeout=1.0)
    except Exception:
        pass
    try:
        if serial_conn is not None:
            with serial_lock:
                if serial_conn.is_open:
                    serial_conn.close()
            serial_conn = None
            logging.info("主串口连接已关闭")
    except Exception:
        logging.exception("关闭串口失败")

def send_serial_click_byte(value=1):
    """通过复用的 serial_conn 发送单字节点击标志；如果 serial_conn 未打开则回退为临时打开发送"""
    global serial_conn
    try:
        if serial_conn is None or not getattr(serial_conn, "is_open", False):
            logging.warning("serial_conn 未打开，尝试临时打开发送")
            # 回退：临时打开端口发送（如果被占用会抛异常）
            s = serial.Serial(port=SERIAL_PORT, baudrate=BAUDRATE, timeout=0.5)
            s.write(bytes([value & 0xFF]))
            s.flush()
            s.close()
            logging.info("临时打开串口并发送点击字节: %s", hex(value & 0xFF))
            return
        with serial_lock:
            serial_conn.write(bytes([value & 0xFF]))
            serial_conn.flush()
        logging.info("通过共享串口发送点击字节: %s", hex(value & 0xFF))
    except Exception:
        logging.exception("发送点击标志失败")
    except Exception:
        logging.exception("发送点击标志失败")

def send_serial_click_async(value=1):
    threading.Thread(target=send_serial_click_byte, args=(value,), daemon=True).start()


def on_canvas_click(event):
    global game_over
    if game_over:
        return
    next_p = get_next_player()
    if is_ai_player(next_p):
        set_status("当前为 AI 回合，等待 AI 下子...")
        return
    x,y = board_coord_from_pixel(event.x, event.y)
    if is_valid_pos(x,y) and board[y][x]==-1:
        ok = place_move(next_p, x, y, from_serial=False)
        if ok:
            # 发送单字节 0x01 表示点击发生（异步）
            send_serial_click_async(1)

def process_move_queue():
    global pending_serial_move
    if pending_serial_move and not game_over:
        p,x,y = pending_serial_move
        if get_next_player() == p:
            logging.info("处理 pending 串口落子: %s,%s,%s", p, x, y)
            place_move(p,x,y,from_serial=True)
            pending_serial_move = None
        else:
            windows.after(50, process_move_queue)
            return

    while not move_queue.empty() and not game_over:
        try:
            raw_p, x, y = move_queue.get_nowait()
        except queue.Empty:
            break
        mapped = serial_map_to_player(raw_p)
        if mapped is None:
            logging.info("当前模式下忽略串口输入: raw %s", raw_p)
            continue
        # 默认行为：只有当轮到该玩家时才处理，否则暂存
        if get_next_player() == mapped:
            logging.info("处理串口落子: mapped %s -> (%s,%s)", mapped, x, y)
            place_move(mapped, x, y, from_serial=True)
        else:
            logging.info("暂存串口落子: mapped %s -> (%s,%s)", mapped, x, y)
            pending_serial_move = (mapped, x, y)
            break

    windows.after(50, process_move_queue)

def build_ui():
    global windows, canvas, status_label, last_move_label
    global game_mode_var, human_side_var, ai_black_var, ai_white_var
    global auto_reset_var

    windows = tk.Tk()
    windows.title("五子棋 - 多模式（A/B/AI/串口） (10x10, 左下为(0,0))")
    width = MARGIN * 2 + CELL_SIZE * (BOARD_SIZE - 1)
    windows.geometry(f"{width}x{width+220}")

    canvas_frame = tk.Frame(windows)
    canvas_frame.pack()
    canvas_widget = tk.Canvas(canvas_frame, width=width, height=width, bg="#F0D9B5")
    canvas_widget.pack()
    canvas_widget.bind("<Button-1>", on_canvas_click)

    ctrl = tk.Frame(windows)
    ctrl.pack(fill="x", pady=6)

    tk.Label(ctrl, text="模式:").pack(side="left")
    game_mode_var = tk.StringVar(value="A_vs_B")
    tk.OptionMenu(ctrl, game_mode_var, "A_vs_B", "Human_vs_AI", "AI_vs_AI").pack(side="left", padx=4)

    tk.Label(ctrl, text=" 人类方:").pack(side="left")
    human_side_var = tk.StringVar(value="Black")
    tk.OptionMenu(ctrl, human_side_var, "Black", "White").pack(side="left", padx=4)

    ai_black_var = tk.BooleanVar(value=False)
    ai_white_var = tk.BooleanVar(value=False)
    tk.Checkbutton(ctrl, text="Black AI", variable=ai_black_var).pack(side="left", padx=4)
    tk.Checkbutton(ctrl, text="White AI", variable=ai_white_var).pack(side="left", padx=4)

    # （已移除）串口合并 A/B 功能

    auto_reset_var = tk.BooleanVar(value=False)
    tk.Checkbutton(ctrl, text="胜利后自动重置", variable=auto_reset_var).pack(side="left", padx=6)

    tk.Button(windows, text="立即 AI 下一步", command=lambda: make_ai_move(get_next_player())).pack(pady=4)

    status_label_local = tk.Label(windows, text="坐标系：左下为 (0,0)。等待串口输入或点击下子", anchor="w")
    status_label_local.pack(fill="x", padx=6)
    tk.Button(windows, text="重置棋盘", command=reset_board).pack(pady=2)
    last_move = tk.Label(windows, text="上一步: 无")
    last_move.pack()

    # bind refs
    canvas = canvas_widget
    status_label = status_label_local
    last_move_label = last_move

    return windows

def on_closing():
    if messagebox.askokcancel("退出", "确定要退出吗？"):
        stop_serial_thread()
        time.sleep(0.2)
        try:
            windows.destroy()
        except Exception:
            pass

def main():
    global windows, canvas, status_label, last_move_label
    windows = build_ui()
    draw_board()
    start_serial_thread()
    windows.after(50, process_move_queue)
    windows.after(200, schedule_ai_for_next)
    windows.protocol("WM_DELETE_WINDOW", on_closing)
    windows.mainloop()

if __name__ == "__main__":
    main()